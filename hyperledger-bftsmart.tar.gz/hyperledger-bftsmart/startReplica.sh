#!/bin/bash
java -cp dist/BFT-Proxy.jar:lib/* bft.BFTNode $@
