#!/bin/bash
echo $BFTSMART_REPLICAS
java -cp dist/BFT-Proxy.jar:lib/* bft.BFTNode $@
